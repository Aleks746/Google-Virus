import os
for i in range(100):
    os.mkdir('Google_'+str(i))
